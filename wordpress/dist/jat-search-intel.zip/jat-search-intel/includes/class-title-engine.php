<?php
namespace JAT_Search_Intel;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Title Template Engine — resolves template variables for dynamic SEO titles.
 *
 * Supported variables:
 *   %title%, %sitename%, %sep%, %category%, %tag%, %date%, %author%, %page%, %excerpt%
 *
 * Templates can be set per-context: single posts, pages, categories, tags,
 * author archives, search, 404, homepage.
 */
class Title_Engine {

    /** @var array */
    private $settings;

    /** @var string[] Default templates per context */
    private static $default_templates = [
        'single'   => '%title% %sep% %sitename%',
        'page'     => '%title% %sep% %sitename%',
        'category' => '%category% %sep% %sitename%',
        'tag'      => '%tag% %sep% %sitename%',
        'taxonomy' => '%title% %sep% %sitename%',
        'archive'  => '%title% %page% %sep% %sitename%',
        'author'   => '%author% %sep% %sitename%',
        'search'   => 'Search: %search_query% %sep% %sitename%',
        '404'      => 'Page Not Found %sep% %sitename%',
        'homepage' => '%sitename%',
    ];

    /**
     * @param array $settings       Plugin settings.
     * @param bool  $register_hooks False to use the resolver without hooking the title filter.
     */
    public function __construct( array $settings, bool $register_hooks = true ) {
        $this->settings = $settings;

        if ( ! $register_hooks || empty( $settings['enable_seo'] ) ) {
            return;
        }

        // Override the existing SEO Manager title filter at a later priority
        add_filter( 'pre_get_document_title', [ $this, 'resolve_title' ], 25 );
    }

    /**
     * Expand variables in a saved title or description, if it has any.
     *
     * @param string $text     Text that may contain %variables%.
     * @param array  $settings Plugin settings.
     * @return string
     */
    public static function expand( string $text, array $settings ): string {
        if ( false === strpos( $text, '%' ) ) {
            return $text;
        }
        return ( new self( $settings, false ) )->resolve_variables( $text );
    }

    /**
     * Sanitize a title or description that may contain %variables%.
     *
     * sanitize_text_field() strips anything that looks like a URL-encoded
     * byte, which turns %category% and %date% into "tegory%" and "te%".
     * This removes tags, line breaks and extra spaces but keeps variables.
     *
     * @param string $text Raw text.
     * @return string
     */
    public static function sanitize_template( string $text ): string {
        $text = wp_check_invalid_utf8( $text );
        $text = wp_strip_all_tags( $text, true );
        $text = (string) preg_replace( '/[\r\n\t ]+/', ' ', $text );
        return trim( $text );
    }

    /**
     * Get the default templates.
     */
    public static function get_default_templates(): array {
        return self::$default_templates;
    }

    /**
     * Resolve the title for the current context using templates.
     */
    public function resolve_title( string $title ): string {
        $templates = $this->settings['title_templates'] ?? [];
        $context   = $this->detect_context();
        $template  = $templates[ $context ] ?? self::$default_templates[ $context ] ?? '%title% %sep% %sitename%';

        // For single posts and pages (a static front page or posts page too), a manual SEO title comes first.
        $posts_page = self::posts_page_id();
        if ( is_singular() || $posts_page ) {
            $post_id   = $posts_page ?: get_queried_object_id();
            $seo_title = (string) get_post_meta( $post_id, '_jat_search_intel_title', true );
            if ( '' !== $seo_title ) {
                // Variables are allowed here too (imported titles often use them).
                return false === strpos( $seo_title, '%' ) ? $seo_title : $this->resolve_variables( $seo_title );
            }
        }

        // A category, tag or other term can set its own title (template variables allowed).
        if ( is_category() || is_tag() || is_tax() ) {
            $custom = Term_SEO::get( get_queried_object_id(), 'title' );
            if ( '' !== $custom ) {
                return trim( (string) preg_replace( '/\s+/', ' ', $this->resolve_variables( $custom ) ) );
            }
        }

        return $this->resolve_variables( $template );
    }

    /**
     * The page chosen as "Posts page" when it is being viewed, else 0.
     *
     * @return int
     */
    public static function posts_page_id(): int {
        if ( ! is_home() || is_front_page() ) {
            return 0;
        }
        return (int) get_option( 'page_for_posts' );
    }

    /**
     * Detect the current page context.
     */
    private function detect_context(): string {
        if ( is_front_page() || is_home() ) {
            return 'homepage';
        }
        if ( is_singular( 'page' ) ) {
            return 'page';
        }
        if ( is_singular() ) {
            return 'single';
        }
        if ( is_category() ) {
            return 'category';
        }
        if ( is_tag() ) {
            return 'tag';
        }
        if ( is_tax() ) {
            return 'taxonomy';
        }
        if ( is_author() ) {
            return 'author';
        }
        if ( is_search() ) {
            return 'search';
        }
        if ( is_404() ) {
            return '404';
        }
        if ( is_archive() ) {
            return 'archive';
        }

        return 'single';
    }

    /**
     * Resolve all template variables in a string.
     */
    public function resolve_variables( string $template ): string {
        // Only resolve variables the template uses (several need extra queries).
        $tokens = [ '%title%', '%sitename%', '%tagline%', '%sep%', '%category%', '%tag%', '%date%', '%author%', '%page%', '%excerpt%', '%search_query%' ];

        $variables = [];
        foreach ( $tokens as $token ) {
            if ( false !== strpos( $template, $token ) ) {
                $variables[ $token ] = $this->resolve_token( $token );
            }
        }

        $resolved = strtr( $template, $variables );

        // Clean up double spaces and trailing separators
        $sep      = $this->get_var_sep();
        $resolved = preg_replace( '/\s+/', ' ', $resolved );
        $resolved = trim( $resolved, " {$sep}" );

        return $resolved;
    }

    /**
     * Value for one template token.
     *
     * @param string $token Token such as %title%.
     * @return string
     */
    private function resolve_token( string $token ): string {
        switch ( $token ) {
            case '%title%':
                return $this->get_var_title();
            case '%sitename%':
                return $this->get_var_sitename();
            case '%tagline%':
                return (string) get_bloginfo( 'description' );
            case '%sep%':
                return $this->get_var_sep();
            case '%category%':
                return $this->get_var_category();
            case '%tag%':
                return $this->get_var_tag();
            case '%date%':
                return $this->get_var_date();
            case '%author%':
                return $this->get_var_author();
            case '%page%':
                return $this->get_var_page();
            case '%excerpt%':
                return $this->get_var_excerpt();
            case '%search_query%':
                return $this->get_var_search_query();
        }
        return '';
    }

    /**
     * Variable resolvers.
     */
    private function get_var_title(): string {
        if ( is_singular() ) {
            return get_the_title( get_queried_object_id() );
        }
        if ( is_category() || is_tag() || is_tax() ) {
            return single_term_title( '', false ) ?: '';
        }
        if ( is_author() ) {
            return get_the_author() ?: '';
        }
        if ( is_post_type_archive() ) {
            return post_type_archive_title( '', false ) ?: '';
        }
        if ( is_archive() ) {
            return trim( wp_strip_all_tags( get_the_archive_title() ) );
        }

        return '';
    }

    private function get_var_sitename(): string {
        return $this->settings['site_name'] ?: get_bloginfo( 'name' );
    }

    private function get_var_sep(): string {
        return $this->settings['separator'] ?? '|';
    }

    private function get_var_category(): string {
        if ( is_category() ) {
            return single_cat_title( '', false ) ?: '';
        }
        if ( is_singular() ) {
            $primary = Primary_Term::get_term( get_queried_object_id(), 'category' );
            return $primary ? $primary->name : '';
        }

        return '';
    }

    private function get_var_tag(): string {
        if ( is_tag() ) {
            return single_tag_title( '', false ) ?: '';
        }
        if ( is_singular() ) {
            $tags = get_the_tags( get_queried_object_id() );
            return is_array( $tags ) && $tags ? $tags[0]->name : ''; // Can be a WP_Error.
        }

        return '';
    }

    private function get_var_date(): string {
        if ( is_singular() ) {
            return (string) get_the_date( '', get_queried_object_id() );
        }
        if ( is_date() ) {
            return (string) get_the_date();
        }

        return '';
    }

    private function get_var_author(): string {
        if ( is_author() ) {
            return get_the_author() ?: '';
        }
        if ( is_singular() ) {
            $author_id = (int) get_post_field( 'post_author', get_queried_object_id() );
            return get_the_author_meta( 'display_name', $author_id ) ?: '';
        }

        return '';
    }

    private function get_var_page(): string {
        $paged = get_query_var( 'paged', 0 );
        if ( $paged > 1 ) {
            /* translators: %d: number. */
            return sprintf( __( 'Page %d', 'jat-search-intel' ), $paged );
        }

        return '';
    }

    private function get_var_excerpt(): string {
        if ( is_singular() ) {
            $post = get_post( get_queried_object_id() );
            if ( $post && $post->post_excerpt ) {
                return wp_strip_all_tags( $post->post_excerpt );
            }
            return wp_trim_words( wp_strip_all_tags( $post->post_content ), 15, '...' );
        }

        return '';
    }

    private function get_var_search_query(): string {
        return is_search() ? get_search_query() : '';
    }
}
