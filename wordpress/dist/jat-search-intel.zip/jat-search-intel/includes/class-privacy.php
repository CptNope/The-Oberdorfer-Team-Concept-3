<?php
namespace JAT_Search_Intel;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Privacy & GDPR compliance — data exporters, erasers, and privacy policy text.
 *
 * @since 1.5.0
 */
class Privacy {

	/**
	 * User meta keys stored by the plugin.
	 *
	 * @var array<string,string>
	 */
	private const USER_META_KEYS = [
		'jat_search_intel_credentials'      => 'Credentials / Qualifications',
		'jat_search_intel_expertise_areas'   => 'Areas of Expertise',
		'jat_search_intel_years_experience'  => 'Years of Experience',
		'jat_search_intel_social_profiles'   => 'Social / Professional Profiles',
		'jat_search_intel_eeat_consent'      => 'E-E-A-T Data Consent',
	];

	/**
	 * Constructor — register privacy hooks.
	 */
	public function __construct() {
		add_action( 'admin_init', [ $this, 'add_privacy_policy_content' ] );
		add_filter( 'wp_privacy_personal_data_exporters', [ $this, 'register_exporter' ] );
		add_filter( 'wp_privacy_personal_data_erasers', [ $this, 'register_eraser' ] );
	}

	/**
	 * Register the personal data exporter.
	 *
	 * @param array $exporters Registered exporters.
	 * @return array
	 */
	public function register_exporter( array $exporters ): array {
		$exporters['jat-search-intel'] = [
			'exporter_friendly_name' => __( 'JAT Search Intel Author Data', 'jat-search-intel' ),
			'callback'               => [ $this, 'export_personal_data' ],
		];
		return $exporters;
	}

	/**
	 * Register the personal data eraser.
	 *
	 * @param array $erasers Registered erasers.
	 * @return array
	 */
	public function register_eraser( array $erasers ): array {
		$erasers['jat-search-intel'] = [
			'eraser_friendly_name' => __( 'JAT Search Intel Author Data', 'jat-search-intel' ),
			'callback'             => [ $this, 'erase_personal_data' ],
		];
		return $erasers;
	}

	/**
	 * Translated labels for the exported user meta keys.
	 *
	 * @return array<string,string>
	 */
	private function get_meta_labels(): array {
		return [
			'jat_search_intel_credentials'     => __( 'Credentials / Qualifications', 'jat-search-intel' ),
			'jat_search_intel_expertise_areas' => __( 'Areas of Expertise', 'jat-search-intel' ),
			'jat_search_intel_years_experience' => __( 'Years of Experience', 'jat-search-intel' ),
			'jat_search_intel_social_profiles' => __( 'Social / Professional Profiles', 'jat-search-intel' ),
			'jat_search_intel_eeat_consent'    => __( 'E-E-A-T Data Consent', 'jat-search-intel' ),
		];
	}

	/**
	 * Export personal data for a user by email.
	 *
	 * @param string $email_address User email.
	 * @param int    $page          Page number (unused, single page).
	 * @return array
	 */
	public function export_personal_data( string $email_address, int $page = 1 ): array {
		$user = get_user_by( 'email', $email_address );

		if ( ! $user ) {
			return [
				'data' => [],
				'done' => true,
			];
		}

		$data = [];

		$labels = $this->get_meta_labels();

		foreach ( self::USER_META_KEYS as $meta_key => $label ) {
			$value = get_user_meta( $user->ID, $meta_key, true );

			if ( empty( $value ) ) {
				continue;
			}

			if ( is_array( $value ) ) {
				$value = implode( ', ', $value );
			}

			$data[] = [
				'name'  => $labels[ $meta_key ] ?? $label,
				'value' => (string) $value,
			];
		}

		$export_items = [];

		if ( ! empty( $data ) ) {
			$export_items[] = [
				'group_id'          => 'jat-search-intel-author',
				'group_label'       => __( 'JAT Search Intel Author Data', 'jat-search-intel' ),
				'group_description' => __( 'Author E-E-A-T data stored by the JAT Search Intel plugin.', 'jat-search-intel' ),
				'item_id'           => 'jat-search-intel-author-' . $user->ID,
				'data'              => $data,
			];
		}

		return [
			'data' => $export_items,
			'done' => true,
		];
	}

	/**
	 * Erase personal data for a user by email.
	 *
	 * @param string $email_address User email.
	 * @param int    $page          Page number (unused, single page).
	 * @return array
	 */
	public function erase_personal_data( string $email_address, int $page = 1 ): array {
		$user = get_user_by( 'email', $email_address );

		if ( ! $user ) {
			return [
				'items_removed'  => false,
				'items_retained' => false,
				'messages'       => [],
				'done'           => true,
			];
		}

		$items_removed = 0;

		foreach ( array_keys( self::USER_META_KEYS ) as $meta_key ) {
			$value = get_user_meta( $user->ID, $meta_key, true );
			if ( ! empty( $value ) ) {
				delete_user_meta( $user->ID, $meta_key );
				$items_removed++;
			}
		}

		return [
			'items_removed'  => $items_removed > 0,
			'items_retained' => false,
			'messages'       => $items_removed > 0
				? [
					sprintf(
										/* translators: %d: number of meta fields removed */
                        __( 'Removed %d JAT Search Intel author data field(s).', 'jat-search-intel' ),
                        $items_removed
                    ),
				]
				: [],
			'done'           => true,
		];
	}

	/**
	 * Add suggested privacy policy content.
	 */
	public function add_privacy_policy_content(): void {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		$content = '<h2>' . __( 'JAT Search Intel Plugin', 'jat-search-intel' ) . '</h2>';

		$content .= '<h3>' . __( 'What personal data we collect and why', 'jat-search-intel' ) . '</h3>';
		$content .= '<p>' . __( 'The JAT Search Intel plugin stores author E-E-A-T (Experience, Expertise, Authoritativeness, Trustworthiness) data on user profiles when explicitly provided by the author. This includes:', 'jat-search-intel' ) . '</p>';
		$content .= '<ul>';
		$content .= '<li>' . __( 'Professional credentials and qualifications', 'jat-search-intel' ) . '</li>';
		$content .= '<li>' . __( 'Areas of expertise', 'jat-search-intel' ) . '</li>';
		$content .= '<li>' . __( 'Years of professional experience', 'jat-search-intel' ) . '</li>';
		$content .= '<li>' . __( 'Social and professional profile URLs', 'jat-search-intel' ) . '</li>';
		$content .= '</ul>';
		$content .= '<p>' . __( 'This data is only collected when an author explicitly provides it via their WordPress user profile, with their consent.', 'jat-search-intel' ) . '</p>';

		$content .= '<h3>' . __( 'How we use your data', 'jat-search-intel' ) . '</h3>';
		$content .= '<p>' . __( 'Author E-E-A-T data is used to generate structured data (JSON-LD) in the HTML source of published content. This helps search engines and AI systems understand the qualifications of content authors. The data is output as machine-readable markup and may be visible in search results.', 'jat-search-intel' ) . '</p>';

		$content .= '<h3>' . __( 'Data storage and retention', 'jat-search-intel' ) . '</h3>';
		$content .= '<p>' . __( 'All data is stored locally in your WordPress database. The plugin does not transmit personal data to any external service by default. SEO analysis scores and post-level metadata are stored as post meta and do not contain personal information.', 'jat-search-intel' ) . '</p>';

		$content .= '<h3>' . __( 'Search engine notifications', 'jat-search-intel' ) . '</h3>';
		$content .= '<p>' . __( 'When enabled (opt-in), the plugin may send sitemap ping requests to Google and Bing when content is published. These requests contain only your sitemap URL and no personal data.', 'jat-search-intel' ) . '</p>';

		$content .= '<h3>' . __( 'Data export and deletion', 'jat-search-intel' ) . '</h3>';
		$content .= '<p>' . __( 'JAT Search Intel fully supports the WordPress personal data export and erasure tools. When a data export or deletion request is processed, all author E-E-A-T data stored by this plugin will be included.', 'jat-search-intel' ) . '</p>';

		wp_add_privacy_policy_content(
			'JAT Search Intel',
			wp_kses_post( $content )
		);
	}
}
