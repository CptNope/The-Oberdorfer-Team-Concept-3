<?php
/**
 * Works out which appointment slots are open.
 *
 * Candidate slots come from your weekly hours (in the site's timezone). A slot is
 * offered only if it, plus its buffers, doesn't overlap anything busy on the
 * checked Google calendars or another booking made here.
 *
 * @package JATCalendarSync
 */

defined( 'ABSPATH' ) || exit;

/**
 * Slot calculator.
 */
final class JATCS_Availability {

	const GENERATION_OPTION = 'jatcs_busy_generation';
	const CACHE_TTL         = 120;

	/**
	 * Calendars whose busy times block slots (canonical references across every service).
	 *
	 * @return string[]
	 */
	public static function conflict_calendars() {
		$out = array();
		foreach ( JATCS_Calendars::blocking() as $service => $ids ) {
			foreach ( $ids as $id ) {
				$out[] = $service . ':' . $id;
			}
		}
		return $out;
	}

	/**
	 * Invalidate cached busy data (after a booking or cancellation).
	 */
	public static function bust_cache() {
		update_option( self::GENERATION_OPTION, (int) get_option( self::GENERATION_OPTION, 0 ) + 1, false );
	}

	/**
	 * Validate a Y-m-d string.
	 *
	 * @param string $date Date.
	 * @return bool
	 */
	public static function is_valid_date( $date ) {
		if ( ! is_string( $date ) || ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $date, $m ) ) {
			return false;
		}
		return checkdate( (int) $m[2], (int) $m[3], (int) $m[1] );
	}

	/**
	 * Extra clear time around work-schedule events, per calendar: [before, after] in seconds.
	 *
	 * "At least N minutes": the booking's own buffers count toward it, so they don't stack.
	 *
	 * @return array<string,int[]>
	 */
	public static function schedule_padding() {
		$calendar = (string) JATCS_Settings::get( 'schedule_calendar' );
		$gap      = (int) JATCS_Settings::get( 'schedule_buffer' ) * MINUTE_IN_SECONDS;
		if ( '' === $calendar || $gap <= 0 ) {
			return array();
		}
		$before = (int) JATCS_Settings::get( 'buffer_before' ) * MINUTE_IN_SECONDS; // Booking's clear time before it (after a shift).
		$after  = (int) JATCS_Settings::get( 'buffer_after' ) * MINUTE_IN_SECONDS;  // Booking's clear time after it (before a shift).
		return array( JATCS_Calendars::canonical( $calendar ) => array( max( 0, $gap - $after ), max( 0, $gap - $before ) ) );
	}

	/**
	 * First and last bookable dates (site timezone, Y-m-d).
	 *
	 * @return array{0:string,1:string}
	 */
	public static function window() {
		$tz    = wp_timezone();
		$today = new DateTimeImmutable( 'today', $tz );
		$days  = max( 1, (int) JATCS_Settings::get( 'max_days' ) );
		$last  = $today->modify( '+' . ( $days - 1 ) . ' days' )->format( 'Y-m-d' );
		$until = self::schedule_horizon();
		if ( null !== $until && $until < $last ) {
			$last = $until;
		}
		return array( $today->format( 'Y-m-d' ), $last );
	}

	/**
	 * Last bookable date allowed by a posted schedule (e.g. Sling shifts in Google Calendar).
	 *
	 * Booking opens only as far as the last upcoming event on the chosen calendar, optionally
	 * through the Sunday of that week. Nothing posted, or the calendar can't be read: closed
	 * (yesterday), so nobody books a time that may still become a shift.
	 *
	 * @return string|null Y-m-d, or null when the setting is off.
	 */
	public static function schedule_horizon() {
		$calendar = (string) JATCS_Settings::get( 'schedule_calendar' );
		if ( '' === $calendar ) {
			return null;
		}
		$week = (int) JATCS_Settings::get( 'schedule_week' );
		$key  = 'jatcs_horizon_' . md5( $calendar . '|' . $week . '|' . (int) get_option( self::GENERATION_OPTION, 0 ) );
		$hit  = get_transient( $key );
		if ( is_string( $hit ) && '' !== $hit ) {
			return $hit;
		}
		$tz     = wp_timezone();
		$closed = ( new DateTimeImmutable( 'yesterday', $tz ) )->format( 'Y-m-d' );
		$end    = JATCS_Calendars::last_event_end( $calendar, max( 31, (int) JATCS_Settings::get( 'max_days' ) + 7 ) );
		if ( is_wp_error( $end ) ) {
			set_transient( $key, $closed, 2 * MINUTE_IN_SECONDS );
			return $closed;
		}
		if ( ! $end ) {
			$until = $closed;
		} else {
			$day = ( new DateTimeImmutable( '@' . ( $end - 1 ) ) )->setTimezone( $tz );
			if ( $week ) {
				$day = $day->modify( '+' . ( ( 7 - (int) $day->format( 'N' ) ) % 7 ) . ' days' );
			}
			$until = $day->format( 'Y-m-d' );
		}
		set_transient( $key, $until, 15 * MINUTE_IN_SECONDS );
		return $until;
	}

	/**
	 * Open slots for each date in a range.
	 *
	 * @param string     $from    First date (Y-m-d, site timezone).
	 * @param string     $to      Last date (Y-m-d, inclusive).
	 * @param bool       $fresh   Bypass the busy-time cache.
	 * @param array|null $type    Appointment type (null: the first active one).
	 * @param array|null $exclude A booking being moved: its own time doesn't count as busy.
	 * @return array<string,int[]>|WP_Error Map of date => list of Unix start times.
	 */
	public static function slots( $from, $to, $fresh = false, $type = null, $exclude = null ) {
		$type = self::resolve_type( $type );
		// A type's times are its host's: their calendars, their bookings, their daily cap.
		return JATCS_Hosts::run(
			JATCS_Hosts::of_type( $type ),
			static function () use ( $from, $to, $fresh, $type, $exclude ) {
				return self::host_slots( $from, $to, $fresh, $type, $exclude );
			}
		);
	}

	/**
	 * Open slots for the current host (see slots()).
	 *
	 * @param string     $from    First date.
	 * @param string     $to      Last date.
	 * @param bool       $fresh   Bypass the busy-time cache.
	 * @param array|null $type    Appointment type.
	 * @param array|null $exclude A booking being moved.
	 * @return array<string,int[]>|WP_Error
	 */
	private static function host_slots( $from, $to, $fresh, $type, $exclude ) {
		if ( ! $type ) {
			return new WP_Error( 'jatcs_no_types', __( 'No appointment types are available.', 'jat-calendar-sync' ) );
		}
		list( $first, $last ) = self::window();
		$from                 = max( $from, $first );
		$to                   = min( $to, $last );
		if ( $from > $to ) {
			return array();
		}

		$candidates = self::candidates( $from, $to, $type );
		$all        = array();
		foreach ( $candidates as $list ) {
			$all = array_merge( $all, $list );
		}
		if ( ! $all ) {
			return $candidates;
		}

		$duration = self::duration_seconds( $type );
		$before   = (int) JATCS_Settings::get( 'buffer_before' ) * MINUTE_IN_SECONDS;
		$after    = (int) JATCS_Settings::get( 'buffer_after' ) * MINUTE_IN_SECONDS;

		$range_start = min( $all ) - $before;
		$range_end   = max( $all ) + $duration + $after;

		$busy = self::busy( $range_start, $range_end, $fresh, $exclude );
		if ( is_wp_error( $busy ) ) {
			return $busy;
		}
		// Appointments booked here keep their own free time before and after, so a new booking
		// can't be squeezed in right after one (Google events only get the new booking's buffers).
		foreach ( JATCS_Bookings::busy_ranges( $range_start - $after, $range_end + $before, $exclude ? (int) $exclude['id'] : 0 ) as $r ) {
			$busy[] = array( $r[0] - $before, $r[1] + $after );
		}

		$limit  = (int) JATCS_Settings::get( 'daily_limit' );
		$counts = $limit > 0 ? JATCS_Bookings::counts_by_date( $from, $to, $exclude ? (int) $exclude['id'] : 0 ) : array();

		$open = array();
		foreach ( $candidates as $date => $starts ) {
			$open[ $date ] = array();
			if ( $limit > 0 && isset( $counts[ $date ] ) && $counts[ $date ] >= $limit ) {
				continue;
			}
			foreach ( $starts as $start ) {
				$a = $start - $before;
				$b = $start + $duration + $after;
				if ( ! self::overlaps( $a, $b, $busy ) ) {
					$open[ $date ][] = $start;
				}
			}
		}
		return $open;
	}

	/**
	 * Is one specific start time bookable right now? Always checks Google live.
	 *
	 * @param int        $start   Unix start time.
	 * @param array|null $type    Appointment type.
	 * @param array|null $exclude Booking being moved.
	 * @return true|WP_Error
	 */
	public static function check_slot( $start, $type = null, $exclude = null ) {
		$date  = wp_date( 'Y-m-d', $start );
		$slots = self::slots( $date, $date, true, $type, $exclude );
		if ( is_wp_error( $slots ) ) {
			return $slots;
		}
		if ( empty( $slots[ $date ] ) || ! in_array( (int) $start, $slots[ $date ], true ) ) {
			return new WP_Error( 'jatcs_slot_taken', __( 'That time was just taken. Pick another time.', 'jat-calendar-sync' ), array( 'status' => 409 ) );
		}
		return true;
	}

	/**
	 * Use the given type, or the first active one.
	 *
	 * @param array|null $type Type.
	 * @return array|null
	 */
	private static function resolve_type( $type ) {
		return is_array( $type ) ? array_merge( JATCS_Types::defaults(), $type ) : JATCS_Types::first();
	}

	/**
	 * Appointment length in seconds.
	 *
	 * @param array|null $type Type (null: the first active one).
	 * @return int
	 */
	public static function duration_seconds( $type = null ) {
		$type = self::resolve_type( $type );
		return max( 5, (int) ( $type ? $type['duration'] : JATCS_Settings::get( 'duration' ) ) ) * MINUTE_IN_SECONDS;
	}

	/**
	 * Slot starts generated from weekly hours, before checking busy times.
	 *
	 * @param string $from First date.
	 * @param string $to   Last date.
	 * @param array  $type Type.
	 * @return array<string,int[]>
	 */
	private static function candidates( $from, $to, array $type ) {
		$tz       = wp_timezone();
		$weekdays = JATCS_Settings::weekdays();
		$hours    = JATCS_Types::hours( $type );
		$duration = (int) max( 5, (int) $type['duration'] );
		$interval = (int) max( 5, (int) $type['interval'] );
		$earliest = time() + (int) JATCS_Settings::get( 'min_notice' ) * HOUR_IN_SECONDS;
		$day      = new DateTimeImmutable( $from . ' 00:00:00', $tz );
		$end      = new DateTimeImmutable( $to . ' 00:00:00', $tz );
		$out      = array();
		$guard    = 0;

		while ( $day <= $end && $guard++ < 400 ) {
			$date         = $day->format( 'Y-m-d' );
			$key          = $weekdays[ (int) $day->format( 'N' ) ];
			$out[ $date ] = array();
			$ranges       = JATCS_Settings::is_day_off( $date ) ? array() : JATCS_Settings::parse_hours( isset( $hours[ $key ] ) ? $hours[ $key ] : '' );

			foreach ( $ranges as $range ) {
				for ( $minute = $range[0]; $minute + $duration <= $range[1]; $minute += $interval ) {
					// setTime() keeps wall-clock times correct across daylight-saving changes.
					$start = $day->setTime( intdiv( $minute, 60 ), $minute % 60 )->getTimestamp();
					if ( $start >= $earliest && ! in_array( $start, $out[ $date ], true ) ) {
						$out[ $date ][] = $start;
					}
				}
			}
			sort( $out[ $date ] );
			$day = $day->modify( '+1 day' );
		}
		return $out;
	}

	/**
	 * Busy ranges from every blocking calendar, cached briefly.
	 *
	 * @param int        $from    Unix start.
	 * @param int        $to      Unix end.
	 * @param bool       $fresh   Bypass cache.
	 * @param array|null $exclude Booking whose own event should not count as busy.
	 * @return array|WP_Error
	 */
	private static function busy( $from, $to, $fresh, $exclude = null ) {
		$skip = $exclude && ! empty( $exclude['event_id'] ) && 'confirmed' === $exclude['status']
			? array(
				'calendar' => (string) $exclude['calendar_id'],
				'start'    => (int) $exclude['start'],
				'end'      => (int) $exclude['end'],
			)
			: null;
		$pad  = self::schedule_padding();
		$key  = 'jatcs_busy_' . md5( wp_json_encode( $pad ) . '|' . $from . '|' . $to . '|' . JATCS_Calendars::fingerprint() . '|' . (int) get_option( self::GENERATION_OPTION, 0 ) . '|' . ( $skip ? implode( ',', $skip ) : '' ) );
		if ( ! $fresh ) {
			$cached = get_transient( $key );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}
		$reach = $pad ? max( array_map( 'max', $pad ) ) : 0; // See shifts just outside the range too.
		// Any calendar that can't be read: offer nothing rather than risk a clash.
		$busy = JATCS_Calendars::busy( $from - $reach, $to + $reach, $skip, $pad );
		if ( ! is_wp_error( $busy ) ) {
			set_transient( $key, $busy, self::CACHE_TTL );
		}
		return $busy;
	}

	/**
	 * Remove [start, end) from a list of ranges.
	 *
	 * @param array $ranges Ranges.
	 * @param int   $start  Start.
	 * @param int   $end    End.
	 * @return array
	 */
	public static function subtract( array $ranges, $start, $end ) {
		$out = array();
		foreach ( $ranges as $r ) {
			if ( $r[1] <= $start || $r[0] >= $end ) {
				$out[] = $r;
				continue;
			}
			if ( $r[0] < $start ) {
				$out[] = array( $r[0], $start );
			}
			if ( $r[1] > $end ) {
				$out[] = array( $end, $r[1] );
			}
		}
		return $out;
	}

	/**
	 * Does [a, b) overlap any busy range?
	 *
	 * @param int   $a    Start.
	 * @param int   $b    End.
	 * @param array $busy Busy ranges.
	 * @return bool
	 */
	private static function overlaps( $a, $b, array $busy ) {
		foreach ( $busy as $range ) {
			if ( $a < $range[1] && $b > $range[0] ) {
				return true;
			}
		}
		return false;
	}
}
